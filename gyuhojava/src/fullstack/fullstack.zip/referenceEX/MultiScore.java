package fullstack.referenceEX;

public class MultiScore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
